R0_ZIP_ENTRY_MARKER 共享目录/同名 guide.md
