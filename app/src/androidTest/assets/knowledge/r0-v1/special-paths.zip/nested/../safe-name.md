R0_ZIP_ENTRY_MARKER nested/../safe-name.md
